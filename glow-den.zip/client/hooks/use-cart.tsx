import { createContext, useContext, useState, ReactNode } from "react";

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  negotiatedPrice?: number;
  negotiatedDiscount?: number;
  image?: string;
  paddlePriceId?: string;
}

interface CartContextType {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  getTotal: () => number;
  getTotalDiscount: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem("talk2deal_cart");
    return saved ? JSON.parse(saved) : [];
  });

  const addItem = (item: CartItem) => {
    setItems((prevItems) => {
      const existingItem = prevItems.find((i) => i.id === item.id);
      let updated;

      if (existingItem) {
        updated = prevItems.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i,
        );
      } else {
        updated = [...prevItems, item];
      }

      localStorage.setItem("talk2deal_cart", JSON.stringify(updated));
      return updated;
    });
  };

  const removeItem = (id: string) => {
    setItems((prevItems) => {
      const updated = prevItems.filter((i) => i.id !== id);
      localStorage.setItem("talk2deal_cart", JSON.stringify(updated));
      return updated;
    });
  };

  const updateQuantity = (id: string, quantity: number) => {
    setItems((prevItems) => {
      const updated = prevItems.map((i) =>
        i.id === id ? { ...i, quantity: Math.max(1, quantity) } : i,
      );
      localStorage.setItem("talk2deal_cart", JSON.stringify(updated));
      return updated;
    });
  };

  const clearCart = () => {
    setItems([]);
    localStorage.removeItem("talk2deal_cart");
  };

  const getTotal = () => {
    return items.reduce((total, item) => {
      const price = item.negotiatedPrice || item.price;
      return total + price * item.quantity;
    }, 0);
  };

  const getTotalDiscount = () => {
    return items.reduce((total, item) => {
      return total + (item.negotiatedDiscount || 0) * item.quantity;
    }, 0);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        getTotal,
        getTotalDiscount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within CartProvider");
  }
  return context;
}
