import { Product } from "@shared/api";

export const products: Product[] = [
  {
    id: "1",
    name: "Premium Wireless Headphones",
    description:
      "High-quality noise-canceling headphones with 40-hour battery life",
    basePrice: 299.99,
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop",
    category: "Electronics",
    rating: 4.8,
    reviewCount: 2453,
    inStock: true,
    paddlePriceId: "pro_01k9f83rsch70x4h37ak227dm8",
  },
  {
    id: "2",
    name: "Smart Watch Pro",
    description: "Advanced fitness tracking and health monitoring smartwatch",
    basePrice: 399.99,
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop",
    category: "Electronics",
    rating: 4.6,
    reviewCount: 1829,
    inStock: true,
  },
  {
    id: "3",
    name: "Ultra HD 4K Webcam",
    description:
      "Professional streaming webcam with auto-focus and built-in microphone",
    basePrice: 189.99,
    image:
      "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&h=400&fit=crop",
    category: "Electronics",
    rating: 4.5,
    reviewCount: 956,
    inStock: true,
  },
  {
    id: "4",
    name: "Ergonomic Gaming Mouse",
    description:
      "Precision gaming mouse with customizable DPI and RGB lighting",
    basePrice: 79.99,
    image:
      "https://images.unsplash.com/photo-1527814050087-3793815479db?w=400&h=400&fit=crop",
    category: "Electronics",
    rating: 4.7,
    reviewCount: 3421,
    inStock: true,
  },
  {
    id: "5",
    name: "Mechanical Keyboard",
    description:
      "Compact mechanical keyboard with mechanical switches and RGB backlighting",
    basePrice: 149.99,
    image:
      "https://images.unsplash.com/photo-1587829191301-51f80f9e12b7?w=400&h=400&fit=crop",
    category: "Electronics",
    rating: 4.9,
    reviewCount: 2156,
    inStock: true,
  },
  {
    id: "6",
    name: "Portable SSD 1TB",
    description: "Fast portable solid-state drive with 1TB storage capacity",
    basePrice: 129.99,
    image:
      "https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=400&h=400&fit=crop",
    category: "Storage",
    rating: 4.8,
    reviewCount: 1742,
    inStock: true,
  },
  {
    id: "7",
    name: "USB-C Hub Adapter",
    description: "Multi-port USB-C hub with HDMI, USB 3.0, and SD card reader",
    basePrice: 49.99,
    image:
      "https://images.unsplash.com/photo-1625948515291-69613efd103f?w=400&h=400&fit=crop",
    category: "Accessories",
    rating: 4.4,
    reviewCount: 834,
    inStock: true,
  },
  {
    id: "8",
    name: "Premium Phone Stand",
    description: "Adjustable phone stand compatible with all devices",
    basePrice: 39.99,
    image:
      "https://images.unsplash.com/photo-1600486613410-a6ae86886d0c?w=400&h=400&fit=crop",
    category: "Accessories",
    rating: 4.3,
    reviewCount: 612,
    inStock: true,
  },
  {
    id: "9",
    name: "Wireless Charging Pad",
    description:
      "Fast wireless charging pad compatible with all Qi-enabled devices",
    basePrice: 34.99,
    image:
      "https://images.unsplash.com/photo-1591290621749-9c1e6f6d66d5?w=400&h=400&fit=crop",
    category: "Accessories",
    rating: 4.6,
    reviewCount: 1203,
    inStock: true,
  },
  {
    id: "10",
    name: "Cable Organizer Kit",
    description: "Complete cable organization solution for your desk setup",
    basePrice: 24.99,
    image:
      "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop",
    category: "Accessories",
    rating: 4.5,
    reviewCount: 521,
    inStock: true,
  },
  {
    id: "11",
    name: "LED Desk Lamp",
    description:
      "Adjustable LED desk lamp with USB charging and brightness control",
    basePrice: 59.99,
    image:
      "https://images.unsplash.com/photo-1565636192335-14f0f4a0a7e4?w=400&h=400&fit=crop",
    category: "Lighting",
    rating: 4.7,
    reviewCount: 1456,
    inStock: true,
  },
  {
    id: "12",
    name: "Desk Mount Clamp",
    description: "Heavy-duty desk mount clamp for monitors and accessories",
    basePrice: 44.99,
    image:
      "https://images.unsplash.com/photo-1589939705882-f4813ff2a5f0?w=400&h=400&fit=crop",
    category: "Accessories",
    rating: 4.4,
    reviewCount: 789,
    inStock: true,
  },
];

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((p) => p.category === category);
}

export function getAllCategories(): string[] {
  return [...new Set(products.map((p) => p.category))];
}
