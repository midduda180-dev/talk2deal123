import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ShoppingCart } from "lucide-react";
import { useEffect, useState } from "react";
import { useCart } from "@/hooks/use-cart";

export default function Checkout() {
  const navigate = useNavigate();
  const { items, getTotal, getTotalDiscount } = useCart();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializePaddle = async () => {
      try {
        const token = import.meta.env.VITE_PADDLE_CLIENT_TOKEN;

        if (!token) {
          console.warn(
            "Paddle token not configured. Using test token for development.",
          );
          // Fallback for development
          return;
        }

        if (typeof window.Paddle !== "undefined") {
          window.Paddle.Initialize({
            token: token,
          });
          setIsLoading(false);
        }
      } catch (error) {
        console.error("Error initializing Paddle:", error);
        setIsLoading(false);
      }
    };

    const timer = setTimeout(initializePaddle, 500);
    return () => clearTimeout(timer);
  }, []);

  const handleCheckout = () => {
    if (typeof window.Paddle !== "undefined") {
      const cartItems = items.map((item) => ({
        priceId: item.paddlePriceId || "pro_01k9f83rsch70x4h37ak227dm8",
        quantity: item.quantity,
      }));

      window.Paddle.Checkout.open({
        items: cartItems,
      });
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <ShoppingCart className="h-16 w-16 text-foreground/20 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-foreground mb-4">
              Your cart is empty
            </h1>
            <p className="text-foreground/70 mb-8">
              Add items to your cart before checking out
            </p>
            <Button
              onClick={() => navigate("/products")}
              className="bg-primary hover:bg-primary/90 text-white"
            >
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const subtotal = items.reduce((total, item) => {
    return total + item.price * item.quantity;
  }, 0);

  const totalDiscount = getTotalDiscount();
  const finalPrice = getTotal();

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-primary hover:text-primary/80 mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Items */}
          <div className="lg:col-span-2">
            <h1 className="text-3xl font-bold text-foreground mb-8">
              Checkout
            </h1>

            {/* Items List */}
            <div className="bg-secondary/50 rounded-lg p-6 mb-8">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Order Items
              </h2>

              <div className="space-y-4">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="border border-border rounded-lg p-4 flex justify-between items-center"
                  >
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground">
                        {item.name}
                      </h3>
                      <p className="text-sm text-foreground/70">
                        Quantity: {item.quantity}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-foreground">
                        $
                        {(
                          (item.negotiatedPrice || item.price) * item.quantity
                        ).toFixed(2)}
                      </p>
                      {item.negotiatedPrice && (
                        <p className="text-sm text-accent">
                          (Negotiated: ${item.negotiatedPrice.toFixed(2)})
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-secondary/50 rounded-lg p-6 sticky top-24">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Order Summary
              </h2>

              <div className="space-y-3 mb-6 pb-6 border-b border-border">
                <div className="flex justify-between text-foreground/70">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>

                {totalDiscount > 0 && (
                  <div className="flex justify-between text-accent font-medium">
                    <span>AI Discounts</span>
                    <span>-${totalDiscount.toFixed(2)}</span>
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center mb-6">
                <span className="text-lg font-bold text-foreground">Total</span>
                <span className="text-2xl font-bold text-primary">
                  ${finalPrice.toFixed(2)}
                </span>
              </div>

              {/* Payment Section */}
              <div className="mb-6">
                <h3 className="font-semibold text-foreground mb-4">Payment</h3>

                {isLoading ? (
                  <p className="text-foreground/70 text-sm">
                    Loading payment options...
                  </p>
                ) : (
                  <div className="border-2 border-primary rounded-lg p-3">
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        id="paddle"
                        name="payment"
                        defaultChecked
                        className="h-4 w-4 text-primary"
                      />
                      <label
                        htmlFor="paddle"
                        className="flex-1 cursor-pointer text-sm text-foreground font-medium"
                      >
                        Paddle Checkout
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {/* Checkout Button */}
              <Button
                onClick={handleCheckout}
                disabled={isLoading}
                className="w-full bg-primary hover:bg-primary/90 text-white h-12 font-semibold"
              >
                Pay with Paddle
              </Button>

              {/* Security Note */}
              <div className="mt-6 p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-900">
                💳 Secure payment powered by Paddle
              </div>

              {/* Back to Cart */}
              <Button
                onClick={() => navigate("/cart")}
                variant="outline"
                className="w-full mt-3 text-primary border-primary hover:bg-primary/10"
              >
                Back to Cart
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
