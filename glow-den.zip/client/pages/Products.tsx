import { Header } from "@/components/Header";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { products, getAllCategories } from "@/lib/products";
import { useState, useMemo } from "react";
import { Filter, X } from "lucide-react";

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [priceRange, setPriceRange] = useState({ min: 0, max: 1000 });
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const categories = getAllCategories();

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const categoryMatch =
        !selectedCategory || product.category === selectedCategory;
      const priceMatch =
        product.basePrice >= priceRange.min &&
        product.basePrice <= priceRange.max;
      return categoryMatch && priceMatch;
    });
  }, [selectedCategory, priceRange]);

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Page Header */}
      <div className="bg-gradient-to-r from-blue-50 to-accent/5 border-b border-primary/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground">
            🛍️ All Products
          </h1>
          <p className="text-muted-foreground mt-2">
            {filteredProducts.length} products ready for negotiation
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar - Desktop */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="bg-white border border-primary/20 rounded-xl p-6 sticky top-20 shadow-sm">
              <h3 className="font-bold text-lg text-foreground mb-6">
                🔍 Filters
              </h3>

              {/* Category Filter */}
              <div className="mb-8">
                <h4 className="font-semibold text-foreground mb-4">Category</h4>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedCategory(null)}
                    className={`block w-full text-left px-3 py-2 rounded-lg transition-all ${
                      selectedCategory === null
                        ? "bg-gradient-to-r from-primary to-blue-600 text-white font-semibold"
                        : "text-foreground hover:bg-blue-50 border border-transparent hover:border-primary/20"
                    }`}
                  >
                    All Categories
                  </button>
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`block w-full text-left px-3 py-2 rounded-lg transition-all ${
                        selectedCategory === category
                          ? "bg-gradient-to-r from-primary to-blue-600 text-white font-semibold"
                          : "text-foreground hover:bg-blue-50 border border-transparent hover:border-primary/20"
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range Filter */}
              <div>
                <h4 className="font-semibold text-foreground mb-4">
                  💰 Price Range
                </h4>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-muted-foreground block mb-2">
                      Min: ${priceRange.min}
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1000"
                      value={priceRange.min}
                      onChange={(e) =>
                        setPriceRange({
                          ...priceRange,
                          min: Math.min(
                            parseInt(e.target.value),
                            priceRange.max
                          ),
                        })
                      }
                      className="w-full accent-primary"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground block mb-2">
                      Max: ${priceRange.max}
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1000"
                      value={priceRange.max}
                      onChange={(e) =>
                        setPriceRange({
                          ...priceRange,
                          max: Math.max(
                            parseInt(e.target.value),
                            priceRange.min
                          ),
                        })
                      }
                      className="w-full accent-primary"
                    />
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Mobile Filter Button */}
          <div className="lg:hidden mb-4">
            <Button
              onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
              variant="outline"
              className="w-full flex items-center justify-center gap-2 border-primary/30 hover:border-primary"
            >
              <Filter className="h-4 w-4" />
              Filters
            </Button>
          </div>

          {/* Mobile Filter Panel */}
          {mobileFilterOpen && (
            <div className="lg:hidden mb-6 bg-white border border-primary/20 rounded-xl p-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg text-foreground">Filters</h3>
                <button
                  onClick={() => setMobileFilterOpen(false)}
                  className="p-1 hover:bg-blue-50 rounded transition-colors"
                  title="Close filters"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Category Filter */}
              <div className="mb-6">
                <h4 className="font-semibold text-foreground mb-4">Category</h4>
                <div className="space-y-2">
                  <button
                    onClick={() => {
                      setSelectedCategory(null);
                      setMobileFilterOpen(false);
                    }}
                    className={`block w-full text-left px-3 py-2 rounded-lg transition-all ${
                      selectedCategory === null
                        ? "bg-primary text-white font-semibold"
                        : "text-foreground hover:bg-blue-50"
                    }`}
                  >
                    All Categories
                  </button>
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => {
                        setSelectedCategory(category);
                        setMobileFilterOpen(false);
                      }}
                      className={`block w-full text-left px-3 py-2 rounded-lg transition-all ${
                        selectedCategory === category
                          ? "bg-primary text-white font-semibold"
                          : "text-foreground hover:bg-blue-50"
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div>
                <h4 className="font-semibold text-foreground mb-4">
                  💰 Price Range
                </h4>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-muted-foreground block mb-2">
                      Min: ${priceRange.min}
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1000"
                      value={priceRange.min}
                      onChange={(e) =>
                        setPriceRange({
                          ...priceRange,
                          min: Math.min(
                            parseInt(e.target.value),
                            priceRange.max
                          ),
                        })
                      }
                      className="w-full accent-primary"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground block mb-2">
                      Max: ${priceRange.max}
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1000"
                      value={priceRange.max}
                      onChange={(e) =>
                        setPriceRange({
                          ...priceRange,
                          max: Math.max(
                            parseInt(e.target.value),
                            priceRange.min
                          ),
                        })
                      }
                      className="w-full accent-primary"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Products Grid */}
          <main className="flex-1">
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center py-20 bg-gradient-to-br from-blue-50 to-accent/5 rounded-xl border border-primary/10">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    No products found
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Try adjusting your filters
                  </p>
                  <Button
                    onClick={() => {
                      setSelectedCategory(null);
                      setPriceRange({ min: 0, max: 1000 });
                    }}
                    className="bg-primary hover:bg-primary/90 text-white"
                  >
                    Reset Filters
                  </Button>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 mt-12">
        <div className="bg-gradient-to-r from-primary via-blue-600 to-accent text-white rounded-2xl p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Negotiate?</h2>
          <p className="text-lg opacity-90 mb-6">
            Pick a product and start talking with our AI - every word counts!
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-foreground to-blue-900 text-white py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2 text-lg">
                <span className="text-2xl">💬</span> Talk2Deal
              </h4>
              <p className="text-sm text-gray-300 font-semibold mb-2">
                talk.deal.win
              </p>
              <p className="text-sm text-gray-300">
                Master your negotiation skills and save real money.
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Shop</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    All Products
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Categories
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Help Center
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Company</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    About Us
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center text-sm text-gray-300">
            <p>© 2024 Talk2Deal. Talk. Deal. Win. 💬</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
