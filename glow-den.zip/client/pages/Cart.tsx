import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { useNavigate } from "react-router-dom";
import { Trash2, ArrowLeft, ShoppingCart } from "lucide-react";

export default function Cart() {
  const navigate = useNavigate();
  const { items, removeItem, updateQuantity, getTotal, getTotalDiscount, clearCart } = useCart();

  const subtotal = items.reduce((total, item) => {
    return total + item.price * item.quantity;
  }, 0);

  const totalDiscount = getTotalDiscount();
  const finalTotal = getTotal();

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <ShoppingCart className="h-16 w-16 text-foreground/20 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-foreground mb-4">
              Your cart is empty
            </h1>
            <p className="text-foreground/70 mb-8">
              Start adding products to build your order
            </p>
            <Button
              onClick={() => navigate("/products")}
              className="bg-primary hover:bg-primary/90 text-white"
            >
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-primary hover:text-primary/80 mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <h1 className="text-3xl font-bold text-foreground mb-8">
              Shopping Cart ({items.length})
            </h1>

            <div className="space-y-4">
              {items.map((item) => {
                const itemDiscount = item.negotiatedDiscount ? item.negotiatedDiscount * item.quantity : 0;
                const itemTotal = (item.negotiatedPrice || item.price) * item.quantity;

                return (
                  <div
                    key={item.id}
                    className="border border-border rounded-lg p-4 flex gap-4"
                  >
                    {/* Product Image */}
                    {item.image && (
                      <div className="w-24 h-24 bg-secondary rounded-lg flex-shrink-0 overflow-hidden">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {/* Product Info */}
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-2">
                        {item.name}
                      </h3>

                      <div className="space-y-1 mb-3">
                        <p className="text-sm text-foreground/70">
                          Price: ${item.price.toFixed(2)}
                        </p>
                        {item.negotiatedPrice && (
                          <p className="text-sm text-accent font-medium">
                            Negotiated: ${item.negotiatedPrice.toFixed(2)}
                          </p>
                        )}
                      </div>

                      {/* Quantity */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() =>
                            updateQuantity(item.id, item.quantity - 1)
                          }
                          className="px-2 py-1 border border-border rounded hover:bg-secondary transition-colors"
                        >
                          −
                        </button>
                        <span className="w-8 text-center font-medium">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(item.id, item.quantity + 1)
                          }
                          className="px-2 py-1 border border-border rounded hover:bg-secondary transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Price & Remove */}
                    <div className="flex flex-col items-end justify-between">
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-destructive hover:text-destructive/80 transition-colors p-2"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                      <div className="text-right">
                        <p className="text-lg font-bold text-primary">
                          ${itemTotal.toFixed(2)}
                        </p>
                        {itemDiscount > 0 && (
                          <p className="text-sm text-accent">
                            -${itemDiscount.toFixed(2)}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Continue Shopping */}
            <Button
              onClick={() => navigate("/products")}
              variant="outline"
              className="mt-8 text-primary border-primary hover:bg-primary/10"
            >
              Continue Shopping
            </Button>
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-secondary/50 rounded-lg p-6 sticky top-24">
              <h2 className="text-xl font-bold text-foreground mb-6">
                Order Summary
              </h2>

              <div className="space-y-3 mb-6 pb-6 border-b border-border">
                <div className="flex justify-between text-foreground/70">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>

                {totalDiscount > 0 && (
                  <div className="flex justify-between text-accent font-medium">
                    <span>AI Discounts</span>
                    <span>-${totalDiscount.toFixed(2)}</span>
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center mb-6">
                <span className="text-lg font-bold text-foreground">Total</span>
                <span className="text-2xl font-bold text-primary">
                  ${finalTotal.toFixed(2)}
                </span>
              </div>

              <Button
                onClick={() => navigate("/checkout")}
                className="w-full bg-primary hover:bg-primary/90 text-white h-12 font-semibold mb-3"
              >
                Proceed to Checkout
              </Button>

              <Button
                onClick={clearCart}
                variant="outline"
                className="w-full text-destructive border-destructive hover:bg-destructive/10"
              >
                Clear Cart
              </Button>

              <div className="mt-6 p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-900">
                💡 Tip: Use the Talk2Deal negotiator on product pages to unlock
                even better prices!
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
