import { Header } from "@/components/Header";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { products } from "@/lib/products";
import { Link } from "react-router-dom";
import { ArrowRight, Zap, TrendingUp, Shield } from "lucide-react";

export default function Index() {
  const featuredProducts = products.slice(0, 8);
  const categories = [...new Set(products.map((p) => p.category))];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary via-blue-600 to-accent text-white overflow-hidden relative">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="mb-4 inline-block">
                <span className="text-sm font-bold tracking-widest text-accent uppercase">
                  💬 Talk. Deal. Win.
                </span>
              </div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                Negotiate Every Price. Win Every Deal.
              </h1>
              <p className="text-lg md:text-xl mb-8 text-white/90 leading-relaxed">
                Welcome to Talk2Deal - The only platform where your negotiation skills matter. Get real price cuts based on how you negotiate, not just luck.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/products">
                  <Button className="w-full sm:w-auto bg-white text-primary hover:bg-gray-100 font-semibold px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all">
                    Start Negotiating
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  className="w-full sm:w-auto border-white text-white hover:bg-white/10 font-semibold px-8 py-6 text-lg"
                >
                  How It Works
                </Button>
              </div>
            </div>

            {/* Hero Illustration */}
            <div className="hidden md:flex items-center justify-center">
              <div className="relative w-full h-96">
                <div className="absolute inset-0 bg-white/10 rounded-full blur-3xl"></div>
                <div className="relative flex items-center justify-center h-full">
                  <div className="text-9xl opacity-30 animate-bounce">💬</div>
                  <div className="absolute bottom-10 right-10 text-6xl animate-pulse">
                    💰
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground">
          Why Talk2Deal?
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-blue-50 to-accent/5 rounded-xl p-8 border border-primary/10 hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-600 text-white rounded-lg flex items-center justify-center mb-4">
              <Zap className="h-6 w-6" />
            </div>
            <h3 className="text-xl font-semibold mb-3 text-foreground">
              Smart AI Negotiation
            </h3>
            <p className="text-muted-foreground">
              Our AI learns your negotiation style and responds fairly based on your skills, not favors.
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-accent/5 rounded-xl p-8 border border-primary/10 hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-600 text-white rounded-lg flex items-center justify-center mb-4">
              <TrendingUp className="h-6 w-6" />
            </div>
            <h3 className="text-xl font-semibold mb-3 text-foreground">
              Real Savings
            </h3>
            <p className="text-muted-foreground">
              Earn discounts up to 10% through genuine negotiation. Better deals for smart shoppers.
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-accent/5 rounded-xl p-8 border border-primary/10 hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-600 text-white rounded-lg flex items-center justify-center mb-4">
              <Shield className="h-6 w-6" />
            </div>
            <h3 className="text-xl font-semibold mb-3 text-foreground">
              Secure & Transparent
            </h3>
            <p className="text-muted-foreground">
              Fair pricing with complete transparency. Your negotiation skills are rewarded honestly.
            </p>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="bg-gradient-to-r from-blue-50 to-accent/5 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-lg font-semibold text-foreground mb-6">
            🛍️ Shop by Category
          </h3>
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <Link
                key={category}
                to={`/products?category=${encodeURIComponent(category)}`}
              >
                <Button
                  variant="outline"
                  className="border-primary/30 text-foreground hover:border-primary hover:text-primary hover:bg-primary/5 transition-all"
                >
                  {category}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Featured Deals
            </h2>
            <p className="text-muted-foreground mt-2">
              Ready to negotiate? Pick a product and start talking
            </p>
          </div>
          <Link to="/products">
            <Button className="bg-primary hover:bg-primary/90 text-white shadow-lg hover:shadow-xl transition-all">
              View All
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-primary via-blue-600 to-accent text-white py-16 rounded-2xl mx-4 sm:mx-6 lg:mx-8 my-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Master the Art of Negotiation?
          </h2>
          <p className="text-lg mb-8 text-white/90">
            Join smart shoppers who save real money through genuine negotiation skills
          </p>
          <Link to="/products">
            <Button className="bg-white text-primary hover:bg-gray-100 font-semibold px-8 py-3 text-lg shadow-lg hover:shadow-xl">
              Start Your First Deal
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-foreground to-blue-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2 text-lg">
                <span className="text-2xl">💬</span> Talk2Deal
              </h4>
              <p className="text-sm text-gray-300 font-semibold mb-2">
                talk.deal.win
              </p>
              <p className="text-sm text-gray-300">
                Master your negotiation skills and save real money.
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Shop</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    All Products
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Categories
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Deals
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Company</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Terms & Conditions
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center text-sm text-gray-300">
            <p>
              © 2024 Talk2Deal. All rights reserved. Talk. Deal. Win. 💬
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
