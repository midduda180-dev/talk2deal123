import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { PriceNegotiator } from "@/components/PriceNegotiator";
import { products, getProductById } from "@/lib/products";
import { useParams, useNavigate } from "react-router-dom";
import {
  Star,
  ShoppingCart,
  Truck,
  Shield,
  ArrowLeft,
  Zap,
  CheckCircle,
} from "lucide-react";
import { useState } from "react";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const { toast } = useToast();
  const product = getProductById(id || "");
  const [quantity, setQuantity] = useState(1);
  const [showNegotiator, setShowNegotiator] = useState(false);
  const [negotiatedPrice, setNegotiatedPrice] = useState<number | null>(null);
  const [negotiatedDiscount, setNegotiatedDiscount] = useState<number>(0);
  const [addedToCart, setAddedToCart] = useState(false);

  const handleAddToCart = () => {
    if (!product) return;

    const discountAmount = negotiatedPrice
      ? product.basePrice - negotiatedPrice
      : 0;

    addItem({
      id: product.id,
      name: product.name,
      price: product.basePrice,
      negotiatedPrice: negotiatedPrice || undefined,
      negotiatedDiscount: discountAmount || undefined,
      quantity: quantity,
      image: product.image,
      paddlePriceId: product.paddlePriceId,
    });

    setAddedToCart(true);
    toast({
      title: "Added to Cart",
      description: `${product.name} x${quantity} added successfully!`,
    });

    setTimeout(() => setAddedToCart(false), 2000);
  };

  const handleCheckout = () => {
    if (!product) return;

    const discountAmount = negotiatedPrice
      ? product.basePrice - negotiatedPrice
      : 0;

    addItem({
      id: product.id,
      name: product.name,
      price: product.basePrice,
      negotiatedPrice: negotiatedPrice || undefined,
      negotiatedDiscount: discountAmount || undefined,
      quantity: quantity,
      image: product.image,
      paddlePriceId: product.paddlePriceId,
    });

    navigate("/checkout");
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">
              Product not found
            </h1>
            <Button
              onClick={() => navigate("/products")}
              className="bg-primary hover:bg-primary/90 text-white"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Products
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-primary hover:text-primary/80 font-semibold transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </button>
      </div>

      {/* Product Detail */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
          {/* Product Image */}
          <div className="flex items-center justify-center bg-gradient-to-br from-blue-50 to-accent/5 rounded-2xl overflow-hidden h-96 md:h-full border border-primary/10">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Product Info */}
          <div className="flex flex-col">
            <p className="text-sm text-primary font-bold uppercase tracking-widest mb-2">
              {product.category}
            </p>

            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating)
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-muted-foreground"
                    }`}
                  />
                ))}
              </div>
              <span className="text-foreground font-semibold">
                {product.rating}
              </span>
              <span className="text-muted-foreground">
                ({product.reviewCount} reviews)
              </span>
            </div>

            {/* Description */}
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              {product.description}
            </p>

            {/* Price Section */}
            <div className="bg-gradient-to-br from-blue-50 to-accent/5 rounded-xl p-6 mb-8 border border-primary/10">
              <p className="text-sm text-muted-foreground mb-2">Price</p>
              <div className="flex items-baseline gap-3 mb-4">
                {negotiatedPrice ? (
                  <>
                    <span className="text-4xl font-bold text-accent">
                      ${negotiatedPrice.toFixed(2)}
                    </span>
                    <span className="text-lg text-muted-foreground line-through">
                      ${product.basePrice.toFixed(2)}
                    </span>
                    <span className="ml-auto bg-accent text-white px-3 py-1 rounded-lg font-bold text-sm">
                      {negotiatedDiscount.toFixed(1)}% off
                    </span>
                  </>
                ) : (
                  <>
                    <span className="text-4xl font-bold text-primary">
                      ${product.basePrice.toFixed(2)}
                    </span>
                    <span className="text-lg text-muted-foreground line-through">
                      ${(product.basePrice * 1.15).toFixed(2)}
                    </span>
                  </>
                )}
              </div>
              <p className="text-sm text-accent font-bold flex items-center gap-1">
                <Zap className="h-4 w-4" />
                {negotiatedPrice
                  ? "✨ You negotiated this price!"
                  : "Negotiate to get a better deal with Talk2Deal"}
              </p>
            </div>

            {/* Features */}
            <div className="space-y-3 mb-8">
              <div className="flex items-center gap-3 text-foreground">
                <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Truck className="h-4 w-4 text-primary" />
                </div>
                <span>Free shipping on orders over $50</span>
              </div>
              <div className="flex items-center gap-3 text-foreground">
                <div className="w-6 h-6 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Shield className="h-4 w-4 text-accent" />
                </div>
                <span>30-day money-back guarantee</span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-primary/20 rounded-lg bg-blue-50">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-4 py-2 hover:bg-primary/10 transition-colors font-semibold text-primary"
                  >
                    −
                  </button>
                  <span className="px-6 py-2 font-bold text-foreground">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-4 py-2 hover:bg-primary/10 transition-colors font-semibold text-primary"
                  >
                    +
                  </button>
                </div>
                <Button
                  disabled={!product.inStock}
                  onClick={handleAddToCart}
                  className={`flex-1 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all ${
                    addedToCart
                      ? "bg-accent text-white"
                      : "bg-accent hover:bg-accent/90 text-white"
                  }`}
                >
                  {addedToCart ? (
                    <>
                      <CheckCircle className="mr-2 h-5 w-5" />
                      Added to Cart!
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="mr-2 h-5 w-5" />
                      Add to Cart{" "}
                      {negotiatedPrice &&
                        `($${(negotiatedPrice * quantity).toFixed(2)})`}
                    </>
                  )}
                </Button>
              </div>

              {!negotiatedPrice && (
                <Button
                  onClick={() => setShowNegotiator(!showNegotiator)}
                  disabled={!product.inStock}
                  className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-primary to-blue-600 text-white hover:shadow-lg transition-all shadow-md"
                >
                  💬 Talk2Deal - Negotiate Price
                </Button>
              )}
              {negotiatedPrice && (
                <Button
                  onClick={() => {
                    setNegotiatedPrice(null);
                    setNegotiatedDiscount(0);
                    setShowNegotiator(false);
                  }}
                  className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-primary to-blue-600 text-white hover:shadow-lg transition-all shadow-md"
                >
                  💬 Negotiate Different Price
                </Button>
              )}

              <Button
                disabled={!product.inStock}
                onClick={handleCheckout}
                className="w-full py-6 text-lg font-semibold border-2 border-primary text-primary hover:bg-primary/5 transition-all"
              >
                Go to Checkout
              </Button>
            </div>

            {!product.inStock && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm font-medium">
                This product is currently out of stock
              </div>
            )}
          </div>
        </div>

        {/* AI Negotiator Modal/Expanded */}
        {showNegotiator && (
          <div className="mb-20">
            <div className="max-w-2xl mx-auto">
              <PriceNegotiator
                productName={product.name}
                basePrice={product.basePrice}
                maxDiscount={0.1}
                onAcceptPrice={(price, discountPercent) => {
                  setNegotiatedPrice(price);
                  setNegotiatedDiscount(discountPercent);
                  setShowNegotiator(false);
                }}
              />
            </div>
          </div>
        )}

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-20 pt-12 border-t border-primary/10">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">
              Related Products
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((p) => (
                <div
                  key={p.id}
                  className="bg-white border border-primary/10 rounded-xl overflow-hidden hover:shadow-lg transition-all cursor-pointer hover:-translate-y-1"
                  onClick={() => navigate(`/product/${p.id}`)}
                >
                  <div className="aspect-square bg-gradient-to-br from-blue-50 to-accent/5 overflow-hidden">
                    <img
                      src={p.image}
                      alt={p.name}
                      className="w-full h-full object-cover hover:scale-110 transition-transform"
                    />
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-primary font-bold uppercase mb-1">
                      {p.category}
                    </p>
                    <h3 className="font-semibold text-foreground line-clamp-2 mb-2">
                      {p.name}
                    </h3>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-primary">
                        ${p.basePrice}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {p.rating} ★
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-foreground to-blue-900 text-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2 text-lg">
                <span className="text-2xl">💬</span> Talk2Deal
              </h4>
              <p className="text-sm text-gray-300 font-semibold mb-2">
                talk.deal.win
              </p>
              <p className="text-sm text-gray-300">
                Master your negotiation skills and save real money.
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Shop</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    All Products
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Help Center
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Company</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    About Us
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
