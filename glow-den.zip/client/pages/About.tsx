import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-4">
            About Talk2Deal
          </h1>
          <p className="text-xl text-muted-foreground">
            Coming soon - Learn about our mission to revolutionize negotiation
          </p>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-accent/5 rounded-2xl p-12 text-center border border-primary/10 shadow-lg">
          <div className="text-6xl mb-6">💬</div>
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Talk. Deal. Win.
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            This page is being developed. Continue exploring our products with
            AI-powered price negotiation or let us know what content you'd like
            to see here.
          </p>
          <Link to="/">
            <Button className="bg-gradient-to-r from-primary to-blue-600 hover:shadow-lg text-white font-semibold px-8 py-3">
              Back to Home
            </Button>
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-foreground to-blue-900 text-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2 text-lg">
                <span className="text-2xl">💬</span> Talk2Deal
              </h4>
              <p className="text-sm text-gray-300 font-semibold mb-2">
                talk.deal.win
              </p>
              <p className="text-sm text-gray-300">
                Master your negotiation skills and save real money.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
