/// <reference types="vite/client" />

interface Window {
  Paddle?: {
    Initialize: (config: { token: string; environment: string }) => void;
    Checkout: {
      open: (config: {
        items: Array<{ priceId: string; quantity: number }>;
      }) => void;
      updateCheckout: (config: { items: Array<{ priceId: string; quantity: number }> }) => void;
    };
    Environment: {
      set: (env: string) => void;
    };
  };
}
