import { useState, useEffect, useRef } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { NegotiationMessage } from "@shared/api";
import { Send, Sparkles, Check, X, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface PriceNegotiatorProps {
  productName: string;
  basePrice: number;
  maxDiscount?: number;
  onAcceptPrice?: (price: number, discountPercent: number) => void;
}

interface NegotiationStats {
  skillLevel: "novice" | "amateur" | "expert";
  negotiationMoves: number;
  bestOffer: number | null;
  userDiscount: number;
  totalSkillPoints: number;
}

const MAX_DISCOUNT_PERCENT = 0.1; // 10% max - internal rule only, never shown to user
const MOVES_FOR_FULL_DISCOUNT = 8;

export function PriceNegotiator({
  productName,
  basePrice,
  maxDiscount = 0.1,
  onAcceptPrice,
}: PriceNegotiatorProps) {
  const [messages, setMessages] = useState<NegotiationMessage[]>([]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [negotiationState, setNegotiationState] = useState<
    "active" | "accepted" | "declined"
  >("active");
  const [agreedPrice, setAgreedPrice] = useState<number | null>(null);
  const [stats, setStats] = useState<NegotiationStats>({
    skillLevel: "novice",
    negotiationMoves: 0,
    bestOffer: null,
    userDiscount: 0,
    totalSkillPoints: 0,
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Initial greeting from AI
    const initialMessage: NegotiationMessage = {
      role: "ai",
      content: `Hey there! 👋 Welcome to Talk2Deal! I'm your negotiation partner. You're interested in the "${productName}" at $${basePrice.toFixed(2)}. Show me your negotiation skills - convince me why you deserve a better price. Let's see what you've got! 💬`,
      timestamp: Date.now(),
    };
    setMessages([initialMessage]);
  }, [productName, basePrice]);

  const assessNegotiationSkill = (userMessage: string, moveCount: number) => {
    let skillScore = 0;

    // Check for compelling persuasive language
    const persuasivePatterns = [
      { words: ["bulk", "wholesale", "volume"], weight: 3 },
      { words: ["loyalty", "repeat", "business"], weight: 3 },
      { words: ["long-term", "commitment", "partnership"], weight: 3 },
      { words: ["industry standard", "market", "competitive"], weight: 2 },
      { words: ["competitor", "comparison", "alternative"], weight: 2 },
      { words: ["budget", "afford", "limited"], weight: 2 },
    ];

    for (const pattern of persuasivePatterns) {
      if (pattern.words.some((word) => userMessage.toLowerCase().includes(word))) {
        skillScore += pattern.weight;
      }
    }

    // Check message length - longer, more detailed messages score higher
    const wordCount = userMessage.split(/\s+/).length;
    if (wordCount > 15) skillScore += 2;
    if (wordCount > 25) skillScore += 1;

    // Check for specific business/reasoning
    const hasReasoning =
      userMessage.toLowerCase().includes("because") ||
      userMessage.toLowerCase().includes("since") ||
      userMessage.toLowerCase().includes("reason");
    if (hasReasoning) skillScore += 2;

    // Check for reasonable price suggestions
    const numberMatch = userMessage.match(/\$?(\d+(?:\.\d{2})?)/);
    if (numberMatch) {
      const suggested = parseFloat(numberMatch[1]);
      const discount = ((basePrice - suggested) / basePrice) * 100;

      if (discount > 0 && discount <= 5) {
        skillScore += 2;
      } else if (discount > 5 && discount <= 8) {
        skillScore += 1;
      }
      if (discount > 8 && moveCount < 5) {
        skillScore -= 1;
      }
    }

    // Politeness
    const politeWords = ["please", "thank you", "appreciate"];
    if (politeWords.some((word) => userMessage.toLowerCase().includes(word))) {
      skillScore += 0.5;
    }

    // Persistence
    if (moveCount > 6) skillScore += 1.5;
    if (moveCount > 8) skillScore += 1;
    if (moveCount > 10) skillScore -= 0.5;

    return Math.max(0, skillScore);
  };

  const getMaxAllowedDiscount = (
    skillPoints: number,
    moveCount: number
  ): number => {
    // Tiered discount unlocking system - variable amounts, not always the same
    if (moveCount < 3) {
      return skillPoints >= 4 ? 0.025 : 0.015; // 2.5% or 1.5%
    } else if (moveCount < 5) {
      return skillPoints >= 6 ? 0.048 : 0.032; // 4.8% or 3.2%
    } else if (moveCount < 8) {
      return skillPoints >= 8 ? 0.065 : 0.052; // 6.5% or 5.2%
    } else {
      // Late game: variable amounts up to 10%
      return Math.min(skillPoints >= 12 ? 0.095 : 0.075, MAX_DISCOUNT_PERCENT);
    }
  };

  const simulateAIResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    const moveCount = stats.negotiationMoves + 1;
    const skillScore = assessNegotiationSkill(userMessage, moveCount);
    const newTotalSkillPoints = stats.totalSkillPoints + skillScore;
    const maxAllowed = getMaxAllowedDiscount(newTotalSkillPoints, moveCount);

    // Update skill level
    let newSkillLevel: "novice" | "amateur" | "expert" = "novice";
    if (newTotalSkillPoints >= 15) newSkillLevel = "expert";
    else if (newTotalSkillPoints >= 8) newSkillLevel = "amateur";

    // Check for deal acceptance
    if (
      lowerMessage.includes("accept") ||
      lowerMessage.includes("deal") ||
      lowerMessage.includes("yes") ||
      lowerMessage.includes("agree")
    ) {
      if (stats.bestOffer && stats.bestOffer > 0) {
        setNegotiationState("accepted");
        setAgreedPrice(stats.bestOffer);
        const discount = ((basePrice - stats.bestOffer) / basePrice) * 100;
        return `🎉 Deal Locked In! Your final price is $${stats.bestOffer.toFixed(2)}. Let's get this to your cart!`;
      }
      return `Let's lock in a price first! What's the final offer you'd like to go with?`;
    }

    // Check for decline
    if (
      lowerMessage.includes("decline") ||
      lowerMessage.includes("no") ||
      lowerMessage.includes("nevermind")
    ) {
      setNegotiationState("declined");
      return `No worries! Come back anytime you're ready to negotiate. Remember: Talk. Deal. Win. 💬`;
    }

    // Extract price from message
    const numberMatch = userMessage.match(/\$?(\d+(?:\.\d{2})?)/);
    const mentionedPrice = numberMatch ? parseFloat(numberMatch[1]) : null;

    if (mentionedPrice && mentionedPrice > 0) {
      const discountPercent = ((basePrice - mentionedPrice) / basePrice) * 100;
      const minPrice = basePrice * (1 - maxAllowed);

      if (mentionedPrice >= basePrice) {
        return `That's the regular price! Come on, you can do better than that. 😏 What's your real offer?`;
      } else if (mentionedPrice < minPrice) {
        // Asking for more than we can offer at this skill level
        const bestOffer = minPrice;
        setStats((prev) => ({
          ...prev,
          bestOffer,
          userDiscount: ((basePrice - bestOffer) / basePrice) * 100,
          skillLevel: newSkillLevel,
          negotiationMoves: moveCount,
          totalSkillPoints: newTotalSkillPoints,
        }));

        if (skillScore >= 5) {
          return `I see your ambition! 🚀 How about $${bestOffer.toFixed(2)}? You're making strong arguments, keep it up!`;
        } else {
          return `That's a bit much right now. 🤔 How about $${bestOffer.toFixed(2)}? Show me better negotiation and we can improve from here.`;
        }
      } else if (mentionedPrice <= minPrice) {
        // Within acceptable range
        setStats((prev) => ({
          ...prev,
          bestOffer: mentionedPrice,
          userDiscount: discountPercent,
          skillLevel: newSkillLevel,
          negotiationMoves: moveCount,
          totalSkillPoints: newTotalSkillPoints,
        }));

        if (newSkillLevel === "expert") {
          return `Now THAT'S smart negotiation! 🎯 $${mentionedPrice.toFixed(2)} works for me. Ready to seal the deal?`;
        } else if (newSkillLevel === "amateur") {
          return `Good offer! 👍 $${mentionedPrice.toFixed(2)} - I respect the hustle. Want to accept, or keep pushing?`;
        } else {
          return `Not bad! 💪 $${mentionedPrice.toFixed(2)} - you're learning. Accept it or convince me you deserve more.`;
        }
      } else {
        // Between current offer and min price
        const counteroffer = Math.max(
          minPrice,
          mentionedPrice - basePrice * 0.02
        );
        setStats((prev) => ({
          ...prev,
          userDiscount: ((basePrice - counteroffer) / basePrice) * 100,
          skillLevel: newSkillLevel,
          negotiationMoves: moveCount,
          totalSkillPoints: newTotalSkillPoints,
        }));

        if (skillScore >= 6) {
          return `You're getting warmer! 🔥 You offered $${mentionedPrice.toFixed(2)}. How about $${counteroffer.toFixed(2)}? Impress me more and I might go lower!`;
        } else {
          return `Nice try! 😊 You offered $${mentionedPrice.toFixed(2)}. I can do $${counteroffer.toFixed(2)}. That's fair for now.`;
        }
      }
    }

    // Generic skill-based responses
    const responses: Record<"expert" | "amateur" | "novice", string[]> = {
      expert: [
        `Now THIS is what I'm talking about! 🔥 You know how to negotiate. Give me a specific price and show me why I should take it.`,
        `You're playing at a high level! 🧠 I can see the strategy. What's your next move?`,
        `Impressive arguments! 💎 You're unlocking better deals with every turn. What's your offer?`,
      ],
      amateur: [
        `You're making real progress! 📈 Keep the momentum - give me a concrete offer with reasoning.`,
        `Good thinking! 🎯 You're getting the hang of this. Let's see your next price point.`,
        `You've got potential! 💪 Show me more of those strong arguments and we can negotiate better.`,
      ],
      novice: [
        `You're just getting started. 🌱 To get better prices, I need to see real reasoning and better arguments. What's your offer?`,
        `Keep trying! 📊 Tell me WHY you deserve a discount. Give me specifics!`,
        `I appreciate the effort! 💬 But you need stronger negotiation tactics. Make a detailed case, then give me a price.`,
      ],
    };

    const selectedResponses = responses[newSkillLevel] || responses.novice;
    const response =
      selectedResponses[Math.floor(Math.random() * selectedResponses.length)];

    let hint = "";
    if (moveCount <= 2) {
      hint = "\n\n💡 Tip: Good reasoning + specific price offers = better results!";
    } else if (moveCount === 3 && newTotalSkillPoints < 5) {
      hint = "\n\n💡 Tip: Why do you deserve a better price? Give me real business reasons!";
    }

    return response + hint;
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || isLoading) return;

    const userMessage: NegotiationMessage = {
      role: "user",
      content: userInput,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setUserInput("");
    setIsLoading(true);

    // Simulate API call with delay
    setTimeout(() => {
      const aiResponse = simulateAIResponse(userInput);
      const aiMessage: NegotiationMessage = {
        role: "ai",
        content: aiResponse,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, aiMessage]);
      setIsLoading(false);

      // Update stats after AI response
      const moveCount = stats.negotiationMoves + 1;
      const skillScore = assessNegotiationSkill(userInput, moveCount);
      setStats((prev) => ({
        ...prev,
        negotiationMoves: moveCount,
        totalSkillPoints: prev.totalSkillPoints + skillScore,
      }));
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-white border border-primary/20 rounded-xl overflow-hidden shadow-lg">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary via-blue-600 to-accent p-4 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            <div>
              <h3 className="font-bold text-lg">Talk2Deal Negotiator</h3>
              <p className="text-xs opacity-90">
                {stats.negotiationMoves} moves | Current offer:{" "}
                {stats.bestOffer ? `$${stats.bestOffer.toFixed(2)}` : "—"}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs opacity-90">Original Price</p>
            <p className="font-bold">${basePrice.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-transparent to-blue-50/30">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={cn(
              "flex gap-3 animate-fadeIn",
              msg.role === "user" ? "justify-end" : "justify-start"
            )}
          >
            {msg.role === "ai" && (
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center flex-shrink-0 text-white text-sm font-bold">
                💬
              </div>
            )}
            <div
              className={cn(
                "max-w-xs md:max-w-md px-4 py-3 rounded-lg text-sm leading-relaxed",
                msg.role === "user"
                  ? "bg-primary text-white rounded-br-none shadow-md"
                  : "bg-white text-foreground border border-primary/20 rounded-bl-none shadow-sm"
              )}
            >
              <p>{msg.content}</p>
            </div>
            {msg.role === "user" && (
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0 text-white text-sm font-bold">
                You
              </div>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center flex-shrink-0 text-white text-sm font-bold">
              💬
            </div>
            <div className="bg-white border border-primary/20 rounded-lg rounded-bl-none px-4 py-3 shadow-sm">
              <div className="flex gap-2">
                <span className="w-2 h-2 bg-primary rounded-full animate-bounce"></span>
                <span className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100"></span>
                <span className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200"></span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Negotiation State Messages */}
      {negotiationState !== "active" && (
        <div
          className={cn(
            "p-4 border-t-2 flex items-center gap-3",
            negotiationState === "accepted"
              ? "bg-green-50 border-green-300"
              : "bg-red-50 border-red-300"
          )}
        >
          {negotiationState === "accepted" ? (
            <>
              <Check className="h-6 w-6 text-green-600 flex-shrink-0" />
              <div>
                <p className="font-bold text-green-700">Deal Accepted! 🎉</p>
                <p className="text-sm text-green-600">
                  Final price: ${agreedPrice?.toFixed(2)}
                </p>
              </div>
            </>
          ) : (
            <>
              <X className="h-6 w-6 text-red-600 flex-shrink-0" />
              <p className="font-bold text-red-700">Negotiation Ended</p>
            </>
          )}
        </div>
      )}

      {/* Input Area */}
      {negotiationState === "active" && (
        <form
          onSubmit={handleSendMessage}
          className="border-t border-primary/10 p-4 bg-white"
        >
          <div className="flex gap-2">
            <Input
              type="text"
              placeholder="Give reasons, then make an offer..."
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              disabled={isLoading}
              className="flex-1 border-primary/20 focus:border-primary"
            />
            <Button
              type="submit"
              disabled={isLoading || !userInput.trim()}
              className="bg-primary hover:bg-primary/90 text-white px-3 shadow-md"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            💡 Pro tip: Detailed reasoning + persistence = better prices!
          </p>
        </form>
      )}

      {/* Action Buttons */}
      {negotiationState === "accepted" && onAcceptPrice && agreedPrice && (
        <div className="border-t border-primary/10 p-4 bg-gradient-to-b from-white to-blue-50 space-y-2">
          <Button
            onClick={() => {
              const discountPercent = ((basePrice - agreedPrice) / basePrice) * 100;
              onAcceptPrice(agreedPrice, discountPercent);
            }}
            className="w-full bg-accent hover:bg-accent/90 text-white font-semibold py-3 shadow-lg flex items-center justify-center gap-2"
          >
            <TrendingDown className="h-4 w-4" />
            Add to Cart - ${agreedPrice.toFixed(2)}
          </Button>
          <Button
            variant="outline"
            className="w-full border-primary/30 text-primary hover:bg-primary/5"
            onClick={() => {
              setMessages([
                {
                  role: "ai",
                  content: `Ready for another round? 💬 Let's negotiate again! What's your strategy for the "${productName}" at $${basePrice.toFixed(2)}?`,
                  timestamp: Date.now(),
                },
              ]);
              setNegotiationState("active");
              setAgreedPrice(null);
              setStats({
                skillLevel: "novice",
                negotiationMoves: 0,
                bestOffer: null,
                userDiscount: 0,
                totalSkillPoints: 0,
              });
            }}
          >
            Negotiate Again
          </Button>
        </div>
      )}
    </div>
  );
}
