import { Product } from "@shared/api";
import { Link } from "react-router-dom";
import { Star, ShoppingCart, Zap } from "lucide-react";
import { Button } from "./ui/button";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Link to={`/product/${product.id}`}>
      <div className="group bg-white border border-primary/10 rounded-xl overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 h-full flex flex-col">
        {/* Image Container */}
        <div className="relative w-full aspect-square bg-gradient-to-br from-blue-50 to-accent/5 overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          {!product.inStock && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="text-white font-semibold">Out of Stock</span>
            </div>
          )}
          {product.inStock && (
            <div className="absolute top-3 right-3 bg-gradient-to-r from-primary to-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
              <Zap className="h-3 w-3" />
              Negotiate
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4 flex flex-col flex-grow">
          <p className="text-xs text-primary font-bold uppercase tracking-wider mb-1">
            {product.category}
          </p>

          <h3 className="text-sm font-bold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>

          <p className="text-xs text-muted-foreground mb-3 line-clamp-2 flex-grow">
            {product.description}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-3.5 w-3.5 ${
                    i < Math.floor(product.rating)
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-muted-foreground"
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">
              {product.rating} ({product.reviewCount})
            </span>
          </div>

          {/* Price and Button */}
          <div className="flex items-center justify-between pt-2 border-t border-primary/5">
            <div className="flex flex-col">
              <span className="text-lg font-bold text-primary">
                ${product.basePrice}
              </span>
              <span className="text-xs text-accent font-semibold">
                💬 Negotiable
              </span>
            </div>
            <Button
              size="sm"
              className="bg-primary hover:bg-primary/90 text-white shadow-md hover:shadow-lg transition-all"
              disabled={!product.inStock}
              onClick={(e) => {
                e.preventDefault();
              }}
            >
              <ShoppingCart className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </Link>
  );
}
