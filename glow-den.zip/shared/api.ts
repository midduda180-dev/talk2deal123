/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

export interface Product {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  image: string;
  category: string;
  rating: number;
  reviewCount: number;
  inStock: boolean;
  paddlePriceId?: string;
}

export interface NegotiationMessage {
  role: "user" | "ai";
  content: string;
  timestamp: number;
}

export interface NegotiationResponse {
  message: string;
  suggestedPrice?: number;
  negotiationState: "open" | "accepted" | "declined";
}

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}
